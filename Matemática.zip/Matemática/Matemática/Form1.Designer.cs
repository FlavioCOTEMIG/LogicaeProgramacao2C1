﻿namespace Matemática
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.btnResult = new System.Windows.Forms.Button();
            this.btnResult2 = new System.Windows.Forms.Button();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblSoma = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.btnResult3 = new System.Windows.Forms.Button();
            this.txtNummmm = new System.Windows.Forms.TextBox();
            this.lblSquare = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum.Location = new System.Drawing.Point(14, 18);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(102, 25);
            this.lblNum.TabIndex = 0;
            this.lblNum.Text = "Triplo de:";
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(110, 24);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(100, 20);
            this.txtNum.TabIndex = 1;
            // 
            // btnResult
            // 
            this.btnResult.Location = new System.Drawing.Point(118, 50);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(75, 23);
            this.btnResult.TabIndex = 2;
            this.btnResult.Text = "resultados";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // btnResult2
            // 
            this.btnResult2.Location = new System.Drawing.Point(156, 194);
            this.btnResult2.Name = "btnResult2";
            this.btnResult2.Size = new System.Drawing.Size(75, 23);
            this.btnResult2.TabIndex = 5;
            this.btnResult2.Text = "resultados";
            this.btnResult2.UseVisualStyleBackColor = true;
            this.btnResult2.Click += new System.EventHandler(this.btnResult2_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(93, 168);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 20);
            this.txtNum1.TabIndex = 4;
            // 
            // lblSoma
            // 
            this.lblSoma.AutoSize = true;
            this.lblSoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoma.Location = new System.Drawing.Point(14, 162);
            this.lblSoma.Name = "lblSoma";
            this.lblSoma.Size = new System.Drawing.Size(73, 25);
            this.lblSoma.TabIndex = 3;
            this.lblSoma.Text = "Soma:";
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(199, 168);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 20);
            this.txtNum2.TabIndex = 6;
            // 
            // btnResult3
            // 
            this.btnResult3.Location = new System.Drawing.Point(174, 360);
            this.btnResult3.Name = "btnResult3";
            this.btnResult3.Size = new System.Drawing.Size(75, 23);
            this.btnResult3.TabIndex = 9;
            this.btnResult3.Text = "resultados";
            this.btnResult3.UseVisualStyleBackColor = true;
            this.btnResult3.Click += new System.EventHandler(this.btnResult3_Click);
            // 
            // txtNummmm
            // 
            this.txtNummmm.Location = new System.Drawing.Point(163, 334);
            this.txtNummmm.Name = "txtNummmm";
            this.txtNummmm.Size = new System.Drawing.Size(100, 20);
            this.txtNummmm.TabIndex = 8;
            // 
            // lblSquare
            // 
            this.lblSquare.AutoSize = true;
            this.lblSquare.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSquare.Location = new System.Drawing.Point(14, 329);
            this.lblSquare.Name = "lblSquare";
            this.lblSquare.Size = new System.Drawing.Size(143, 25);
            this.lblSquare.TabIndex = 7;
            this.lblSquare.Text = "Quadrado de:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 450);
            this.Controls.Add(this.btnResult3);
            this.Controls.Add(this.txtNummmm);
            this.Controls.Add(this.lblSquare);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.btnResult2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblSoma);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.lblNum);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.Button btnResult2;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblSoma;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Button btnResult3;
        private System.Windows.Forms.TextBox txtNummmm;
        private System.Windows.Forms.Label lblSquare;
    }
}

