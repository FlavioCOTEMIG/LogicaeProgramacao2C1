﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Matemática
{
    class Math
    {
        public void Triplo(int num)
        {
            int result = num * 3;
            MessageBox.Show("O triplo de " + num + " é: " + result);
        }

        public void Soma(int num1, int num2)
        {
            int result = num1 + num2;
            MessageBox.Show(num1 + "+" + num2 + "=" + result);
        }

        public void Quadrado(int num)
        {
            int result = num * num;
            MessageBox.Show("O quadrado de " + num + " é: " + result);
        }
    }
}
