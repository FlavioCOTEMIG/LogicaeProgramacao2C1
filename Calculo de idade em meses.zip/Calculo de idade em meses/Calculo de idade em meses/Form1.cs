﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculo_de_idade_em_meses
{
    public partial class FrmIdade : Form
    {
        public FrmIdade()
        {
            InitializeComponent();
        }

        private void btnIdade_Click(object sender, EventArgs e)
        {
            int idade = int.Parse(txtIdade.Text);
            int meses;

            meses = idade * 12;

            MessageBox.Show("Idade em meses: " + meses);
        }

        private void btnValor_Click(object sender, EventArgs e)
        {
            int produto = int.Parse(txtValor.Text);
            int valor;

            valor = (int)(produto * 0.1);

            MessageBox.Show("Valor: " + valor);
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            int numero = int.Parse(txtNumero.Text);
            int resultado;

            resultado = (int)(numero * 0.5);

            MessageBox.Show("Resultado: " + resultado);
        }
    }
}
