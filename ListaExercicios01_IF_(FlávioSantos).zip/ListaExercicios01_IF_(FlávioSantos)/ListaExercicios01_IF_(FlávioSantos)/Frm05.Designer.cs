﻿namespace ListaExercicios01_IF__FlávioSantos_
{
    partial class Frm05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm05));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm01 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm02 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm03 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm04 = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblValLanche = new System.Windows.Forms.Label();
            this.txtValLanche = new System.Windows.Forms.TextBox();
            this.txtValPago = new System.Windows.Forms.TextBox();
            this.lblValPago = new System.Windows.Forms.Label();
            this.btnResultado = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirMenuStrip});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirMenuStrip
            // 
            this.exibirMenuStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirFrm01,
            this.exibirFrm02,
            this.exibirFrm03,
            this.exibirFrm04});
            this.exibirMenuStrip.Name = "exibirMenuStrip";
            this.exibirMenuStrip.Size = new System.Drawing.Size(47, 20);
            this.exibirMenuStrip.Text = "Exibir";
            // 
            // exibirFrm01
            // 
            this.exibirFrm01.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm01.Image")));
            this.exibirFrm01.Name = "exibirFrm01";
            this.exibirFrm01.Size = new System.Drawing.Size(127, 22);
            this.exibirFrm01.Text = "Questão 1";
            // 
            // exibirFrm02
            // 
            this.exibirFrm02.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm02.Image")));
            this.exibirFrm02.Name = "exibirFrm02";
            this.exibirFrm02.Size = new System.Drawing.Size(127, 22);
            this.exibirFrm02.Text = "Questão 2";
            // 
            // exibirFrm03
            // 
            this.exibirFrm03.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm03.Image")));
            this.exibirFrm03.Name = "exibirFrm03";
            this.exibirFrm03.Size = new System.Drawing.Size(127, 22);
            this.exibirFrm03.Text = "Questão 3";
            // 
            // exibirFrm04
            // 
            this.exibirFrm04.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm04.Image")));
            this.exibirFrm04.Name = "exibirFrm04";
            this.exibirFrm04.Size = new System.Drawing.Size(127, 22);
            this.exibirFrm04.Text = "Questão 4";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(317, 97);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(152, 39);
            this.lblTitulo.TabIndex = 21;
            this.lblTitulo.Text = "Quetão5";
            // 
            // lblValLanche
            // 
            this.lblValLanche.AutoSize = true;
            this.lblValLanche.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValLanche.Location = new System.Drawing.Point(40, 203);
            this.lblValLanche.Name = "lblValLanche";
            this.lblValLanche.Size = new System.Drawing.Size(138, 19);
            this.lblValLanche.TabIndex = 22;
            this.lblValLanche.Text = "Valor do lanche:";
            // 
            // txtValLanche
            // 
            this.txtValLanche.Location = new System.Drawing.Point(44, 235);
            this.txtValLanche.Name = "txtValLanche";
            this.txtValLanche.Size = new System.Drawing.Size(100, 20);
            this.txtValLanche.TabIndex = 23;
            // 
            // txtValPago
            // 
            this.txtValPago.Location = new System.Drawing.Point(44, 343);
            this.txtValPago.Name = "txtValPago";
            this.txtValPago.Size = new System.Drawing.Size(100, 20);
            this.txtValPago.TabIndex = 25;
            // 
            // lblValPago
            // 
            this.lblValPago.AutoSize = true;
            this.lblValPago.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValPago.Location = new System.Drawing.Point(40, 311);
            this.lblValPago.Name = "lblValPago";
            this.lblValPago.Size = new System.Drawing.Size(101, 19);
            this.lblValPago.TabIndex = 24;
            this.lblValPago.Text = "Valor pago:";
            // 
            // btnResultado
            // 
            this.btnResultado.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResultado.Location = new System.Drawing.Point(516, 258);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(151, 72);
            this.btnResultado.TabIndex = 26;
            this.btnResultado.Text = "Resultado";
            this.btnResultado.UseVisualStyleBackColor = true;
            // 
            // Frm05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(152)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.txtValPago);
            this.Controls.Add(this.lblValPago);
            this.Controls.Add(this.txtValLanche);
            this.Controls.Add(this.lblValLanche);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Frm05";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "  ";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm01;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm02;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm03;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm04;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblValLanche;
        private System.Windows.Forms.TextBox txtValLanche;
        private System.Windows.Forms.TextBox txtValPago;
        private System.Windows.Forms.Label lblValPago;
        private System.Windows.Forms.Button btnResultado;
    }
}