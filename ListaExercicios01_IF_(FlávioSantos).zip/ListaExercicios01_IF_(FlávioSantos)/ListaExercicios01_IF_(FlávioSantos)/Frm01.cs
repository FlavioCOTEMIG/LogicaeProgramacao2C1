﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF__FlávioSantos_
{
    public partial class Frm01 : Form
    {
        public Frm01()
        {
            InitializeComponent();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            float Valor1 = float.Parse(txtValor1.Text);
            float Valor2 = float.Parse(txtValor2.Text);

            if (Valor1 < Valor2)
            {
                lblResultadoValor1.Text = "O valor1 é menor".ToString();
                lblResultadoValor2.Text = "O valor2 é maior".ToString();
            }
            else if (Valor1 == Valor2)
            {
                lvlValoresIguais.Text = "Os 2 valres são iguais".ToString();
            }
            else
            {
                lblResultadoValor1.Text = "O valor1 é maior".ToString();
                lblResultadoValor2.Text = "O valor2 é menor".ToString();
            }

        }

        private void exibirFrm01_Click_1(object sender, EventArgs e)
        {
            Frm01 frm01 = new Frm01();
            this.Hide();
            frm01.ShowDialog();
        }

        private void exibirFrm02_Click(object sender, EventArgs e)
        {
            Frm02 frm02 = new Frm02();
            this.Hide();
            frm02.ShowDialog();
        }

        private void exibirFrm03_Click(object sender, EventArgs e)
        {
            Frm03 frm03 = new Frm03();
            this.Hide();
            frm03.ShowDialog();
        }

        private void exibirFrm04_Click(object sender, EventArgs e)
        {
            Frm04 frm04 = new Frm04();
            this.Hide();
            frm04.ShowDialog();
        }

        private void questão5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm05 frm05 = new Frm05();
            this.Hide();
            frm05.ShowDialog();
        }
    }
}
