﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF__FlávioSantos_
{
    public partial class Frm06 : Form
    {
        public Frm06()
        {
            InitializeComponent();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            float Lados = float.Parse(txtLados.Text);

            if (Lados == 3)
            {
                lblResultado.Text = "Resultado: Triângulo";
            }

            else if (Lados == 4)
            {
                lblResultado.Text = "Resultado: Quadrado";
            }
        }
    }
}
