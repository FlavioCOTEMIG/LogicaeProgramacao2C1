﻿namespace ListaExercicios01_IF__FlávioSantos_
{
    partial class Frm01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm01));
            this.lblResultadoValor2 = new System.Windows.Forms.Label();
            this.lblResultadoValor1 = new System.Windows.Forms.Label();
            this.btnResultado = new System.Windows.Forms.Button();
            this.txtValor2 = new System.Windows.Forms.TextBox();
            this.txtValor1 = new System.Windows.Forms.TextBox();
            this.lblValor2 = new System.Windows.Forms.Label();
            this.lblValor1 = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm01 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm02 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm03 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm04 = new System.Windows.Forms.ToolStripMenuItem();
            this.lvlValoresIguais = new System.Windows.Forms.Label();
            this.questão5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questão6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questão7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questão8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questão9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questão10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questão11ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questão12ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblResultadoValor2
            // 
            this.lblResultadoValor2.AutoSize = true;
            this.lblResultadoValor2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoValor2.Location = new System.Drawing.Point(452, 249);
            this.lblResultadoValor2.Name = "lblResultadoValor2";
            this.lblResultadoValor2.Size = new System.Drawing.Size(0, 25);
            this.lblResultadoValor2.TabIndex = 19;
            // 
            // lblResultadoValor1
            // 
            this.lblResultadoValor1.AutoSize = true;
            this.lblResultadoValor1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoValor1.Location = new System.Drawing.Point(452, 166);
            this.lblResultadoValor1.Name = "lblResultadoValor1";
            this.lblResultadoValor1.Size = new System.Drawing.Size(0, 25);
            this.lblResultadoValor1.TabIndex = 18;
            // 
            // btnResultado
            // 
            this.btnResultado.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResultado.Location = new System.Drawing.Point(298, 340);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(186, 104);
            this.btnResultado.TabIndex = 17;
            this.btnResultado.Text = "RESULTADO";
            this.btnResultado.UseVisualStyleBackColor = true;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // txtValor2
            // 
            this.txtValor2.Location = new System.Drawing.Point(48, 255);
            this.txtValor2.Name = "txtValor2";
            this.txtValor2.Size = new System.Drawing.Size(100, 20);
            this.txtValor2.TabIndex = 16;
            // 
            // txtValor1
            // 
            this.txtValor1.Location = new System.Drawing.Point(48, 172);
            this.txtValor1.Name = "txtValor1";
            this.txtValor1.Size = new System.Drawing.Size(100, 20);
            this.txtValor1.TabIndex = 15;
            // 
            // lblValor2
            // 
            this.lblValor2.AutoSize = true;
            this.lblValor2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor2.Location = new System.Drawing.Point(44, 233);
            this.lblValor2.Name = "lblValor2";
            this.lblValor2.Size = new System.Drawing.Size(59, 19);
            this.lblValor2.TabIndex = 14;
            this.lblValor2.Text = "Valor2";
            // 
            // lblValor1
            // 
            this.lblValor1.AutoSize = true;
            this.lblValor1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor1.Location = new System.Drawing.Point(44, 150);
            this.lblValor1.Name = "lblValor1";
            this.lblValor1.Size = new System.Drawing.Size(59, 19);
            this.lblValor1.TabIndex = 13;
            this.lblValor1.Text = "Valor1";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(12, 50);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(152, 39);
            this.lblTitulo.TabIndex = 12;
            this.lblTitulo.Text = "Quetão1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirMenuStrip});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirMenuStrip
            // 
            this.exibirMenuStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirFrm01,
            this.exibirFrm02,
            this.exibirFrm03,
            this.exibirFrm04,
            this.questão5ToolStripMenuItem,
            this.questão6ToolStripMenuItem,
            this.questão7ToolStripMenuItem,
            this.questão8ToolStripMenuItem,
            this.questão9ToolStripMenuItem,
            this.questão10ToolStripMenuItem,
            this.questão11ToolStripMenuItem,
            this.questão12ToolStripMenuItem});
            this.exibirMenuStrip.Name = "exibirMenuStrip";
            this.exibirMenuStrip.Size = new System.Drawing.Size(47, 20);
            this.exibirMenuStrip.Text = "Exibir";
            // 
            // exibirFrm01
            // 
            this.exibirFrm01.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm01.Image")));
            this.exibirFrm01.Name = "exibirFrm01";
            this.exibirFrm01.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm01.Text = "Questão 1";
            this.exibirFrm01.Click += new System.EventHandler(this.exibirFrm01_Click_1);
            // 
            // exibirFrm02
            // 
            this.exibirFrm02.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm02.Image")));
            this.exibirFrm02.Name = "exibirFrm02";
            this.exibirFrm02.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm02.Text = "Questão 2";
            this.exibirFrm02.Click += new System.EventHandler(this.exibirFrm02_Click);
            // 
            // exibirFrm03
            // 
            this.exibirFrm03.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm03.Image")));
            this.exibirFrm03.Name = "exibirFrm03";
            this.exibirFrm03.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm03.Text = "Questão 3";
            this.exibirFrm03.Click += new System.EventHandler(this.exibirFrm03_Click);
            // 
            // exibirFrm04
            // 
            this.exibirFrm04.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm04.Image")));
            this.exibirFrm04.Name = "exibirFrm04";
            this.exibirFrm04.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm04.Text = "Questão 4";
            this.exibirFrm04.Click += new System.EventHandler(this.exibirFrm04_Click);
            // 
            // lvlValoresIguais
            // 
            this.lvlValoresIguais.AutoSize = true;
            this.lvlValoresIguais.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlValoresIguais.Location = new System.Drawing.Point(452, 200);
            this.lvlValoresIguais.Name = "lvlValoresIguais";
            this.lvlValoresIguais.Size = new System.Drawing.Size(0, 25);
            this.lvlValoresIguais.TabIndex = 20;
            // 
            // questão5ToolStripMenuItem
            // 
            this.questão5ToolStripMenuItem.Name = "questão5ToolStripMenuItem";
            this.questão5ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão5ToolStripMenuItem.Text = "Questão 5";
            this.questão5ToolStripMenuItem.Click += new System.EventHandler(this.questão5ToolStripMenuItem_Click);
            // 
            // questão6ToolStripMenuItem
            // 
            this.questão6ToolStripMenuItem.Name = "questão6ToolStripMenuItem";
            this.questão6ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão6ToolStripMenuItem.Text = "Questão 6";
            // 
            // questão7ToolStripMenuItem
            // 
            this.questão7ToolStripMenuItem.Name = "questão7ToolStripMenuItem";
            this.questão7ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão7ToolStripMenuItem.Text = "Questão 7";
            // 
            // questão8ToolStripMenuItem
            // 
            this.questão8ToolStripMenuItem.Name = "questão8ToolStripMenuItem";
            this.questão8ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão8ToolStripMenuItem.Text = "Questão 8";
            // 
            // questão9ToolStripMenuItem
            // 
            this.questão9ToolStripMenuItem.Name = "questão9ToolStripMenuItem";
            this.questão9ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão9ToolStripMenuItem.Text = "Questão 9";
            // 
            // questão10ToolStripMenuItem
            // 
            this.questão10ToolStripMenuItem.Name = "questão10ToolStripMenuItem";
            this.questão10ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão10ToolStripMenuItem.Text = "Questão 10";
            // 
            // questão11ToolStripMenuItem
            // 
            this.questão11ToolStripMenuItem.Name = "questão11ToolStripMenuItem";
            this.questão11ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão11ToolStripMenuItem.Text = "Questão 11";
            // 
            // questão12ToolStripMenuItem
            // 
            this.questão12ToolStripMenuItem.Name = "questão12ToolStripMenuItem";
            this.questão12ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão12ToolStripMenuItem.Text = "Questão 12";
            // 
            // Frm01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lvlValoresIguais);
            this.Controls.Add(this.lblResultadoValor2);
            this.Controls.Add(this.lblResultadoValor1);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.txtValor2);
            this.Controls.Add(this.txtValor1);
            this.Controls.Add(this.lblValor2);
            this.Controls.Add(this.lblValor1);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Frm01";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm01";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResultadoValor2;
        private System.Windows.Forms.Label lblResultadoValor1;
        private System.Windows.Forms.Button btnResultado;
        private System.Windows.Forms.TextBox txtValor2;
        private System.Windows.Forms.TextBox txtValor1;
        private System.Windows.Forms.Label lblValor2;
        private System.Windows.Forms.Label lblValor1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm01;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm02;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm03;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm04;
        private System.Windows.Forms.Label lvlValoresIguais;
        private System.Windows.Forms.ToolStripMenuItem questão5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão10ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão11ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão12ToolStripMenuItem;
    }
}