﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapiturandoDados
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em enviar!");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label Inteiro!");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto!");
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu formulário!");
        }
    }
}
