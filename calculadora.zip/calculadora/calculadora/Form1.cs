﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float numero1 = float.Parse(txtNum1.Text);
            float numero2 = float.Parse(txtNum2.Text);
            float soma;

            soma = numero1 + numero2;
            MessageBox.Show("Soma = " + soma);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            float numero1 = float.Parse(txtNum1.Text);
            float numero2 = float.Parse(txtNum2.Text);
            float subtracao;

            subtracao = numero1 - numero2;
            MessageBox.Show("Subtracao = " + subtracao);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            float numero1 = float.Parse(txtNum1.Text);
            float numero2 = float.Parse(txtNum2.Text);
            float multiplicacao;

            multiplicacao = numero1 * numero2;
            MessageBox.Show("Multiplicacao = " + multiplicacao);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float numero1 = float.Parse(txtNum1.Text);
            float numero2 = float.Parse(txtNum2.Text);
            float divisao;

            divisao = numero1 / numero2;
            MessageBox.Show("Divisao = " + divisao);
        }
    }
}
